<?php

namespace Codesleeve\LaravelStapler\Exceptions;

use Exception;

class InvalidClassException extends Exception
{
}
